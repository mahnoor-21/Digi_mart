package com.example.degi_mart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
