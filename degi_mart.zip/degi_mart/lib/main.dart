import 'package:degi_mart/pages/consts.dart';
import 'package:degi_mart/pages/start_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_gemini/flutter_gemini.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  Gemini.init(
    apiKey: GEMINI_API_KEY,
  );
  runApp(DigiMartApp());
}

class DigiMartApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Scaffold(
        body: DigiMartPage(),
      ),
    );
  }
}
