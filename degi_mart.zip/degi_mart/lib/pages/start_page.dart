import 'package:degi_mart/pages/create_account.dart';
import 'package:degi_mart/pages/login_page.dart';
import 'package:flutter/material.dart';
class DigiMartPage extends StatelessWidget {
  const DigiMartPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(0.5),
            child: Stack(
              children: [
                Positioned(
                  top: -50,
                  left: -20,
                  right: 170,
                  child: Container(
                    height: 260,
                    decoration:  BoxDecoration(
                      color: Colors.blue.shade100,
                      borderRadius: const BorderRadius.only(
                        bottomLeft: Radius.circular(100),
                        bottomRight: Radius.circular(200),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: -80,
                  left: -100,
                  right: 100,
                  child: Container(
                    height: 210,
                    decoration:  BoxDecoration(
                      color: Colors.blue.shade100,
                      borderRadius: const BorderRadius.only(
                        bottomLeft: Radius.circular(180),
                        bottomRight: Radius.circular(200),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: -80,
                  left: -150,
                  right: 150,
                  child: Container(
                    height: 250,
                    decoration: const BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(200),
                        bottomRight: Radius.circular(300),
                      ),
                    ),
                  ),
                ),
                Center(
                  child: Column(
                    children: [
                      const SizedBox(height: 250),
                      Container(
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                          boxShadow: [BoxShadow(blurRadius: 2, color: Colors.grey, spreadRadius: 1)],
                        ),
                        child: const CircleAvatar(
                          radius: 80,
                          backgroundColor: Colors.white,
                          child: Icon(
                            Icons.shopping_bag,
                            color: Colors.blue,
                            size: 90,
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        'DIGI-MART',
                        style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                      const Text(
                        'Buyers and Sellers paradise',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey,
                        ),
                      ),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              children: [
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {  Navigator.push(context,MaterialPageRoute(
    builder: (context)=> const CreateAccountPage()));},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 16.0),
                    ),
                    child: const Text(
                      "Let's get started",
                      style: TextStyle(fontSize: 18,
                      color: Colors.white
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                GestureDetector(
                  onTap:        (){   Navigator.push(context,MaterialPageRoute(
                    builder: (context)=> LoginPage()));},
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'I already have an account',
                        style: TextStyle(fontSize: 16, color: Colors.grey,
                        ),
                      ),
                      SizedBox(width: 8),
                      Icon(
                        Icons.arrow_forward,
                        color: Colors.blue,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
